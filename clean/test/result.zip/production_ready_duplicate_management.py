
import hashlib
import os
import logging
from collections import defaultdict

logging.basicConfig(filename='duplicate_management.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

def generate_file_hash(filepath):
    sha256_hash = hashlib.sha256()
    with open(filepath, 'rb') as f:
        for byte_block in iter(lambda: f.read(4096), b''):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()

def compare_file_sizes(file1, file2):
    return file1 if os.path.getsize(file1) > os.path.getsize(file2) else file2

def group_files_by_hash(directory):
    file_groups = defaultdict(list)
    for root, _, files in os.walk(directory):
        for filename in files:
            filepath = os.path.join(root, filename)
            file_hash = generate_file_hash(filepath)
            file_groups[file_hash].append(filepath)
    return file_groups

def manage_symlinks(file_path):
    if os.path.islink(file_path):
        logging.info(f'Symlink managed: {file_path}')

def remove_duplicate_files(file_groups):
    for hash_value, files in file_groups.items():
        if len(files) > 1:
            largest_file = max(files, key=os.path.getsize)
            for file in files:
                if file != largest_file:
                    os.remove(file)
                    logging.info(f'Duplicate removed: {file}')
                    manage_symlinks(file)

if __name__ == '__main__':
    try:
        directory_to_scan = input('Enter directory to scan: ')
        file_groups = group_files_by_hash(directory_to_scan)
        remove_duplicate_files(file_groups)
        logging.info('Duplicate file management completed.')
    except Exception as e:
        logging.error(f'Error: {e}')
