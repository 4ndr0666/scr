Module                  Size  Used by
vfat                   24576  1
fat                   106496  1 vfat
ext4                 1196032  1
crc16                  16384  1 ext4
mbcache                16384  1 ext4
jbd2                  217088  1 ext4
snd_seq_dummy          16384  0
snd_hrtimer            16384  1
snd_seq               114688  7 snd_seq_dummy
snd_seq_device         16384  1 snd_seq
exfat                 114688  0
rfkill                 40960  1
qrtr                   57344  4
sg                     53248  0
st                     81920  0
sr_mod                 28672  0
intel_rapl_msr         20480  0
intel_rapl_common      40960  1 intel_rapl_msr
x86_pkg_temp_thermal    20480  0
intel_powerclamp       20480  0
coretemp               20480  0
kvm_intel             454656  0
snd_hda_codec_realtek   212992  1
kvm                  1396736  1 kvm_intel
snd_hda_codec_generic   122880  1 snd_hda_codec_realtek
iTCO_wdt               16384  0
irqbypass              16384  1 kvm
ledtrig_audio          16384  1 snd_hda_codec_generic
intel_pmc_bxt          16384  1 iTCO_wdt
iTCO_vendor_support    16384  1 iTCO_wdt
snd_hda_intel          65536  1
snd_intel_dspcfg       36864  1 snd_hda_intel
snd_intel_sdw_acpi     20480  1 snd_intel_dspcfg
snd_hda_codec         225280  3 snd_hda_codec_generic,snd_hda_intel,snd_hda_codec_realtek
snd_hda_core          143360  4 snd_hda_codec_generic,snd_hda_intel,snd_hda_codec,snd_hda_codec_realtek
snd_hwdep              20480  1 snd_hda_codec
snd_pcm               212992  3 snd_hda_intel,snd_hda_codec,snd_hda_core
snd_timer              57344  3 snd_seq,snd_hrtimer,snd_pcm
snd                   155648  13 snd_hda_codec_generic,snd_seq,snd_seq_device,snd_hwdep,snd_hda_intel,snd_hda_codec,snd_hda_codec_realtek,snd_timer,snd_pcm
at24                   28672  0
soundcore              16384  1 snd
think_lmi              40960  0
rapl                   20480  0
intel_cstate           24576  0
wmi_bmof               16384  0
intel_uncore          262144  0
firmware_attributes_class    16384  1 think_lmi
mousedev               24576  0
joydev                 28672  0
i2c_i801               45056  0
lpc_ich                28672  0
i2c_smbus              20480  1 i2c_i801
mac_hid                16384  0
uinput                 24576  0
crypto_user            20480  0
fuse                  217088  5
zram                   49152  2
bpf_preload            24576  0
ip_tables              36864  0
x_tables               65536  1 ip_tables
overlay               212992  1
squashfs               98304  4
loop                   40960  8
isofs                  65536  1
cdrom                  86016  2 isofs,sr_mod
hid_logitech_hidpp     73728  0
hid_logitech_dj        40960  0
crct10dif_pclmul       16384  1
crc32_pclmul           16384  0
polyval_clmulni        16384  0
polyval_generic        16384  1 polyval_clmulni
gf128mul               20480  1 polyval_generic
ghash_clmulni_intel    16384  0
cryptd                 28672  1 ghash_clmulni_intel
r8169                 131072  0
sha512_ssse3           57344  0
realtek                40960  1
uas                    36864  0
mdio_devres            16384  1 r8169
usb_storage            94208  2 uas
libphy                204800  3 r8169,mdio_devres,realtek
usbhid                 86016  2 hid_logitech_dj,hid_logitech_hidpp
i915                 4042752  16
intel_gtt              32768  1 i915
drm_buddy              20480  1 i915
video                  77824  1 i915
wmi                    45056  3 video,wmi_bmof,think_lmi
drm_display_helper    221184  1 i915
cec                    98304  2 drm_display_helper,i915
ttm                   110592  1 i915
dm_mirror              28672  0
dm_region_hash         28672  1 dm_mirror
dm_log                 28672  2 dm_region_hash,dm_mirror
dm_mod                225280  31 dm_log,dm_mirror
btrfs                2097152  0
blake2b_generic        20480  0
xor                    24576  1 btrfs
raid6_pq              122880  1 btrfs
libcrc32c              16384  1 btrfs
crc32c_generic         16384  0
crc32c_intel           24576  3

