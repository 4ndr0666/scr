mkinitcpio --config /etc/mkinitcpio-custom.conf --generate /boot/initramfs-custom.img


