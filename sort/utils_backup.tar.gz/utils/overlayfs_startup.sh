#!/bin/bash

# Load the OverlayFS module
modprobe overlay
if [ $? -ne 0 ]; then
    echo "Error: Failed to load the overlay module."
    exit 1
fi

# Mount the persistence drive if not already mounted
if ! grep -qs '/run/archiso/cowspace/persistent_ ' /proc/mounts; then
    mount /dev/sdd /run/archiso/cowspace/persistent_
    if [ $? -ne 0 ]; then
        echo "Error: Failed to mount the persistence drive."
        exit 1
    fi
fi

# Create directories for upper, work, and mount point
mkdir -p /run/archiso/cowspace/persistent_/upper
mkdir -p /run/archiso/cowspace/persistent_/work
mkdir -p /run/archiso/cowspace/persistent_/new_root

# Mount the OverlayFS
mount -t overlay overlay -o lowerdir=/run/archiso/airootfs,upperdir=/run/archiso/cowspace/persistent_/upper,workdir=/run/archiso/cowspace/persistent_/work /run/archiso/cowspace/persistent_/new_root
if [ $? -ne 0 ]; then
    echo "Error: Failed to mount the OverlayFS."
    exit 1
fi

# Exit the script
exit 0
