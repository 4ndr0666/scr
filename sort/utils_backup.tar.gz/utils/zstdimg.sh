 #!/bin/bash

 # Define color variables
 NORMAL_COLOR="\e[38;2;84;187;200m"
 INACTIVE_COLOR="\e[38;2;21;21;21m"
 RESET_COLOR="\e[0m"

 # Prompt the user for the partition to compress
 echo -e "${NORMAL_COLOR}Enter the partition to compress (e.g., /dev/sdc3): ${RESET_COLOR}"
 read -p "" SOURCE

 # Check if the source partition exists
 if [ ! -e "$SOURCE" ]; then
   echo -e "${INACTIVE_COLOR}Source partition does not exist.${RESET_COLOR}"
   exit 1
 fi

 # Check if the source partition is mounted
 if mountpoint -q "$SOURCE"; then
   echo -e "${INACTIVE_COLOR}Source partition is currently mounted. Please unmount it before
 proceeding.${RESET_COLOR}"
   exit 1
 fi

 # Prompt the user for the destination path and filename
 echo -e "${NORMAL_COLOR}Enter the destination path and filename for the recovery image: ${RESET_COLOR}"
 read -p "" DESTINATION

 # Check if the destination file already exists
 if [ -e "$DESTINATION" ]; then
   echo -e "${INACTIVE_COLOR}Destination file already exists. Please choose a different
 destination.${RESET_COLOR}"
   exit 1
 fi

 # Compress the source partition and create the recovery image using zstd
 if ! sudo dd if="$SOURCE" bs=4M | \
 xz -9 -e -c "$DESTINATION"; then
 #zstd -T0 -19 -o "$DESTINATION"; then
 #gzip -9 -o "$DESTINATION"; then
   echo -e "${INACTIVE_COLOR}Error occurred during compression. Please check the source partition and destinatio
 path.${RESET_COLOR}"
   exit 1
 fi

 # Verify the integrity of the recovery image
 if ! zstd -t "$DESTINATION"; then
   echo -e "${INACTIVE_COLOR}Recovery image verification failed. Please try creating the recovery image
 again.${RESET_COLOR}"
   exit 1
 fi

 echo -e "${NORMAL_COLOR}Recovery image created successfully at $DESTINATION.${RESET_COLOR}"
